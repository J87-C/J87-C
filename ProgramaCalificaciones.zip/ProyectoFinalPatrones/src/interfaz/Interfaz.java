
package interfaz;

import java.util.Scanner;
import mundo.Calificacion;
import mundo.CorteEvaluativo;
import mundo.Curso;
import mundo.Estudiante;
import mundo.GestorCalificaciones;

/**
 *
 * @author Lenovo
 */
public class Interfaz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        GestorCalificaciones gestor = GestorCalificaciones.getInstancia();

        // Crear curso y cortes evaluativos
        System.out.println("Ingrese el nombre del curso:");
        String nombreCurso = sc.nextLine();

        int creditosCurso = 0;
        while (true) {
            try {
                System.out.println("Ingrese los creditos del curso:");
                creditosCurso = sc.nextInt();
                sc.nextLine(); // Consumir salto de línea
                break; // Salir del bucle si la entrada es válida
            } catch (Exception e) {
                System.out.println("Por favor, ingrese un número entero valido.");
                sc.nextLine(); // Consumir entrada incorrecta
            }
        }

        Curso curso = new Curso(1, nombreCurso, creditosCurso);

        int numCortes = 0;
        while (true) {
            try {
                System.out.println("Ingrese el numero de cortes evaluativos:");
                numCortes = sc.nextInt();
                sc.nextLine(); // Consumir salto de línea
                break;
            } catch (Exception e) {
                System.out.println("Por favor, ingrese un número entero valido.");
                sc.nextLine(); // Consumir entrada incorrecta
            }
        }

        for (int i = 0; i < numCortes; i++) {
            System.out.println("Ingrese el nombre del corte evaluativo " + (i + 1) + ":");
            String nombreCorte = sc.nextLine();

            double porcentajeCorte = 0;
            while (true) {
                try {
                    System.out.println("Ingrese el porcentaje del corte evaluativo " + (i + 1) + ":");
                    porcentajeCorte = sc.nextDouble();
                    sc.nextLine(); // Consumir salto de línea
                    break;
                } catch (Exception e) {
                    System.out.println("Por favor, ingrese un numero valido (por ejemplo: 50.0).");
                    sc.nextLine(); // Consumir entrada incorrecta
                }
            }

            CorteEvaluativo corte = new CorteEvaluativo(i + 1, nombreCorte, porcentajeCorte);
            curso.agregarCorte(corte);
        }

        // Crear estudiante
        System.out.println("Ingrese el nombre del estudiante:");
        String nombreEstudiante = sc.nextLine();

        Estudiante estudiante = new Estudiante(1, nombreEstudiante);

        // Asignar calificaciones
        for (CorteEvaluativo corte : curso.getCortes()) {
            double nota = 0;
            while (true) {
                try {
                    System.out.println("Ingrese la calificacion para el corte " + corte.getNombre() + ":");
                    nota = sc.nextDouble();
                    sc.nextLine(); // Consumir salto de línea
                    break;
                } catch (Exception e) {
                    System.out.println("Por favor, ingrese un numero valido (por ejemplo: 4,5).");
                    sc.nextLine(); // Consumir entrada incorrecta
                }
            }

            Calificacion calificacion = new Calificacion(corte.getId(), nota);
            gestor.asignarCalificacion(estudiante, curso, corte, calificacion);
        }

        // Consultar promedios
        System.out.println("\nResultados");
        gestor.consultarPromedios(estudiante, curso);
    }
}
