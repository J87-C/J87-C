/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author Lenovo
 */
public class Calificacion {
    private int id;
    private double nota;

    public Calificacion(int id, double nota) {
        this.id = id;
        this.nota = nota;
    }

    public int getId() {
        return id;
    }
    
    public double getNota() {
        return nota;
    }

    public boolean validarNota() {
        return nota >= 0 && nota <= 5; // Nota en escala de 0 a 5
    }

}
