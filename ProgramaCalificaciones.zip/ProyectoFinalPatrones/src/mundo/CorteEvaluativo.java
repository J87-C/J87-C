/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class CorteEvaluativo {
    private int id;
    private String nombre;
    private double porcentaje;
    private List<Calificacion> calificaciones = new ArrayList<>();

    public CorteEvaluativo(int id, String nombre, double porcentaje) {
        this.id = id;
        this.nombre = nombre;
        this.porcentaje = porcentaje;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPorcentaje() {
        return porcentaje;
    }

    public List<Calificacion> getCalificaciones() {
        return calificaciones;
    }
    
    public void agregarCalificación(Calificacion calificacion) {
        calificaciones.add(calificacion);
    }

    public double obtenerPromedioCorte() {
        double suma = 0;
        for (Calificacion cal : calificaciones) {
            suma += cal.getNota() * (porcentaje / 100);
        }
        return suma;
    }
}
