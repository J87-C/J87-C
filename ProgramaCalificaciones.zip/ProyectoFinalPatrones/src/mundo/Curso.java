/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Curso {
    private int id;
    private String nombre;
    private int creditos;
    private List<CorteEvaluativo> cortes = new ArrayList<>();

    public Curso(int id, String nombre, int creditos) {
        this.id = id;
        this.nombre = nombre;
        this.creditos = creditos;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void agregarCorte(CorteEvaluativo corte) {
        cortes.add(corte);
    }
    
    public List<CorteEvaluativo> getCortes() {
        return cortes;
    }

    public double obtenerPromedioCurso() {
        double suma = 0;
        for (CorteEvaluativo corte : cortes) {
            suma += corte.obtenerPromedioCorte();
        }
        return cortes.size() > 0 ? suma / cortes.size() : 0;
    }
}
