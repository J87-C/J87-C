
package mundo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Estudiante implements Observador {
    private int id;
    private String nombre;
    private List<Calificacion> calificaciones = new ArrayList<>();

    public Estudiante(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarCalificación(Calificacion calificacion) {
        calificaciones.add(calificacion);
        notificarCalificacion(calificacion);
    }

    public double obtenerPromedio() {
        double suma = 0;
        for (Calificacion cal : calificaciones) {
            suma += cal.getNota();
        }
        return calificaciones.size() > 0 ? suma / calificaciones.size() : 0;
    }

    private void notificarCalificacion(Calificacion calificacion) {
        System.out.println("Notificación para " + nombre + ": Se ha registrado una nueva calificación de " 
                           + calificacion.getNota());
    }

    public void actualizar(Estudiante estudiante, CorteEvaluativo corte, Calificacion calificacion) {
        System.out.println("El estudiante " + estudiante.getNombre() + " ha sido notificado sobre su calificación "
                + calificacion.getNota() + " para el corte " + corte.getNombre());
    }
}
