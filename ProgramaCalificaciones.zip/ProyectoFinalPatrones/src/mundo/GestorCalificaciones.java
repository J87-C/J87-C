/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class GestorCalificaciones {private static GestorCalificaciones instancia;
    private List<Calificacion> calificaciones; // Lista para almacenar calificaciones
    private List<Observador> observadores;

    // Singleton

    private GestorCalificaciones() {
        calificaciones = new ArrayList<>(); // Inicializar la lista
        observadores = new ArrayList<>();
    }

    public static GestorCalificaciones getInstancia() {
        if (instancia == null) {
            instancia = new GestorCalificaciones();
        }
        return instancia;
    }
    
    public void registrarObservador(Observador observador) {
        observadores.add(observador);
    }
    
    public void notificar(Estudiante estudiante, CorteEvaluativo corte, Calificacion calificacion) {
        for (Observador observador : observadores) {
            observador.actualizar(estudiante, corte, calificacion); // Llamada a actualizar()
        }
    }

    // Asignar calificación
    public void asignarCalificacion(Estudiante estudiante, Curso curso, CorteEvaluativo corte, Calificacion calificacion) {
        calificaciones.add(calificacion);
        notificar(estudiante, corte, calificacion); // Notificar a todos los observadores
        System.out.println("Calificación asignada: " + calificacion.getNota() + " al estudiante " + estudiante.getNombre()
                + " para el corte " + corte.getNombre() + " del curso " + curso.getNombre());
    }

    // Obtener calificación
    public Calificacion obtenerCalificacion(Estudiante estudiante, Curso curso, CorteEvaluativo corte) {
        for (Calificacion cal : calificaciones) { // Buscar en la lista
            if (cal.getId() == corte.getId()) {
                return cal;
            }
        }
        return null; // Si no se encuentra
    }

    // Consultar promedios
    public void consultarPromedios(Estudiante estudiante, Curso curso) {
        System.out.println("\n--- Promedios del Estudiante: " + estudiante.getNombre() + " ---");
        double promedioPonderado = 0.0;

        if (curso.getCortes().isEmpty()) {
            System.out.println("El curso " + curso.getNombre() + " no tiene cortes evaluativos asignados.");
            return;
        }

        for (CorteEvaluativo corte : curso.getCortes()) {
            Calificacion calificacion = obtenerCalificacion(estudiante, curso, corte);
            if (calificacion != null) {
                double notaPonderada = calificacion.getNota() * (corte.getPorcentaje() / 100.0);
                promedioPonderado += notaPonderada;
                System.out.println("- Corte: " + corte.getNombre() 
                                   + " | Porcentaje: " + corte.getPorcentaje() + "%" 
                                   + " | Nota: " + calificacion.getNota() 
                                   + " | Nota Ponderada: " + notaPonderada);
            } else {
                System.out.println("- Corte: " + corte.getNombre() + " | Nota: No asignada");
            }
        }

        System.out.println("\nPromedio ponderado del curso " + curso.getNombre() + ": " + promedioPonderado);
    }
}
